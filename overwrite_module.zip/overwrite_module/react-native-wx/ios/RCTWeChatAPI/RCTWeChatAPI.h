//
//  RCTWeChatAPI.h
//  RCTWeChatAPI
//
//  Created by LvBingru on 1/6/16.
//  Copyright © 2016 erica. All rights reserved.
//

#import "RCTBridgeModule.h"

@interface RCTWeChatAPI : NSObject <RCTBridgeModule>

@end
