//
//  RCTWeChatAPI.m
//  RCTWeChatAPI
//
//  Created by LvBingru on 1/6/16.
//  Copyright © 2016 erica. All rights reserved.
//


#import "RCTLog.h"
#import "RCTWeChatAPI.h"
#import "WXApi.h"
#import "WXApiObject.h"
#import "RCTEventDispatcher.h"
#import "RCTBridge.h"
#import "RCTImageLoader.h"

#define RCTWXShareTypeNews @"news"
#define RCTWXShareTypeImage @"image"
#define RCTWXShareTypeText @"text"
#define RCTWXShareTypeVideo @"video"
#define RCTWXShareTypeAudio @"audio"

#define RCTWXShareType @"type"
#define RCTWXShareTitle @"title"
#define RCTWXShareText @"text"
#define RCTWXShareDescription @"description"
#define RCTWXShareWebpageUrl @"webpageUrl"
#define RCTWXShareImageUrl @"imageUrl"
#define RCTWXShareThumbImageSize @"thumbImageSize"

#define NOT_REGISTERED (@"registerApp required.")
#define INVOKE_FAILED (@"WeChat API invoke returns false.")

@interface RCTWeChatAPI()<WXApiDelegate>
@end

static NSString *gAppID = @"";
static BOOL gIsAppRegistered = false;

@implementation RCTWeChatAPI

@synthesize bridge = _bridge;

RCT_EXPORT_MODULE()

- (NSDictionary *)constantsToExport
{
    return @{ @"isAppRegistered":@(gIsAppRegistered)};
}

- (dispatch_queue_t)methodQueue
{
    return dispatch_get_main_queue();
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self _autoRegisterAPI];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleOpenURL:) name:@"RCTOpenURLNotification" object:nil];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

RCT_EXPORT_METHOD(isWXAppInstalled:(RCTResponseSenderBlock)callback)
{
//    if([WXApi isWXAppInstalled]){
//        callback(@[@YES]);
//    }
//    else {
//        callback(@[[NSNull null], @([WXApi isWXAppInstalled])]);
//    }
    
    callback(@[[NSNull null], @([WXApi isWXAppInstalled])]);
    
}

RCT_EXPORT_METHOD(isWXAppSupportApi:(RCTResponseSenderBlock)callback)
{
    callback(@[[NSNull null], @([WXApi isWXAppSupportApi])]);
}

RCT_EXPORT_METHOD(login:(NSDictionary *)config
                  :(RCTResponseSenderBlock)callback)
{
    SendAuthReq* req = [[SendAuthReq alloc] init];
    req.scope = config[@"scope"];
    req.state = config[@"state"]?:[NSDate date].description;
    BOOL success = [WXApi sendReq:req];
    callback(@[success ? [NSNull null] : INVOKE_FAILED]);
}

RCT_EXPORT_METHOD(shareToTimeline:(NSDictionary *)data
                  :(RCTResponseSenderBlock)callback)
{
    [self shareToWeixinWithData:data scene:WXSceneTimeline callback:callback];
}

RCT_EXPORT_METHOD(shareBase64PhotoToTimeLine:(NSString*)base64 withText:(NSString *) text callback:(RCTResponseSenderBlock)callback){
    

    
    BOOL success = [self shareBase64PhotoToSence:base64 withText:text sence:WXSceneTimeline];
    if (success == NO)
    {
        callback(@[INVOKE_FAILED]);
    }
    
}

-(BOOL)shareBase64PhotoToSence:(NSString*)base64 withText:(NSString *) text sence:(int)sence
{
    SendMessageToWXReq * req = [SendMessageToWXReq new];
    WXMediaMessage * message = [WXMediaMessage message];
    WXImageObject * imageObject = [WXImageObject object];
    imageObject.imageData = [[NSData alloc] initWithBase64EncodedString:base64 options:0];
    message.mediaObject = imageObject;
    //    message.title = @"aaa";
    //    message.description = @"bbb";
    message.mediaTagName = @"Webuzz";
    UIImage * BaseImage = [[UIImage alloc] initWithData:imageObject.imageData];
    UIImage *resultImg = [self addImage:BaseImage addImage1:[UIImage imageNamed:@"img-waterprint.png"] image1Width:60.0f image1Height:30.0f];
    message.thumbData = UIImageJPEGRepresentation([self getThumbData:BaseImage],1.0);
    //    resultImg = [self addText:resultImg text:@"Webuzz"];
    imageObject.imageData = UIImageJPEGRepresentation(resultImg,1.0);
    req.bText = NO;
    req.message = message;
    req.scene = sence;
    req.text = @"Send from Webuzz";
    
    return [WXApi sendReq:req];
}

RCT_EXPORT_METHOD(shareLinkToTimeLine:(NSString*)urlString
//                  photoBase64:(NSString*)base64
                  withTitle:(NSString*)title
                  withDesc:(NSString*)desc
                  callback:(RCTResponseSenderBlock)callback
                  ){
    SendMessageToWXReq * req = [SendMessageToWXReq new];
    WXMediaMessage * message = [WXMediaMessage message];
    
    message.mediaTagName = @"Webuzz";
//    UIImage * BaseImage = [[UIImage alloc] initWithData:[[NSData alloc] initWithBase64EncodedString:base64 options:0]];
//    [message setThumbImage:BaseImage];
    message.title = title;
    message.description = desc;
    
    WXWebpageObject *webpage = [WXWebpageObject object];
    webpage.webpageUrl = urlString;
    
    
    message.mediaObject = webpage;
    
    req.bText = NO;
    req.message = message;
    req.scene = WXSceneTimeline;
    req.text = @"Send from Webuzz";
    
    BOOL success = [WXApi sendReq:req];
    if (success == NO)
    {
        callback(@[INVOKE_FAILED]);
    }
}

RCT_EXPORT_METHOD(shareLinkToSession:(NSString*)urlString
//                  photoBase64:(NSString*)base64
                  withTitle:(NSString*)title
                  withDesc:(NSString*)desc
                  callback:(RCTResponseSenderBlock)callback
                  ){
    SendMessageToWXReq * req = [SendMessageToWXReq new];
    WXMediaMessage * message = [WXMediaMessage message];
    
    message.mediaTagName = @"Webuzz";
//    UIImage * BaseImage = [[UIImage alloc] initWithData:[[NSData alloc] initWithBase64EncodedString:base64 options:0]];
//    [message setThumbImage:BaseImage];
    message.title = title;
    message.description = desc;
    
    WXWebpageObject *webpage = [WXWebpageObject object];
    webpage.webpageUrl = urlString;
    
    
    message.mediaObject = webpage;
    
    req.bText = NO;
    req.message = message;
    req.scene = WXSceneSession;
    req.text = @"Send from Webuzz";
    
    BOOL success = [WXApi sendReq:req];
    if (success == NO)
    {
        callback(@[INVOKE_FAILED]);
    }
}

RCT_EXPORT_METHOD(shareAppExtentToTimeLine:(NSString*)extInfo
                  url:(NSString*)url
                  photoBase64:(NSString*)base64
                  withTitle:(NSString*)title
                  description:(NSString *)desc
                  data:(NSData*) data
                  callback:(RCTResponseSenderBlock)callback
                  ){
    BOOL success =[self shareAppExtentToScene:extInfo url:url photoBase64:base64 withTitle:title description:desc data:data sence:WXSceneTimeline];
    if (success == NO)
    {
        callback(@[INVOKE_FAILED]);
    }
}

RCT_EXPORT_METHOD(shareAppExtentToSession:(NSString*)extInfo
                  url:(NSString*)url
                  photoBase64:(NSString*)base64
                  withTitle:(NSString*)title
                  description:(NSString *)desc
                  data:(NSData*) data
                  callback:(RCTResponseSenderBlock)callback
                  ){
    BOOL success =[self shareAppExtentToScene:extInfo url:url photoBase64:base64 withTitle:title description:desc data:data sence:WXSceneSession];
    if (success == NO)
    {
        callback(@[INVOKE_FAILED]);
    }
}

-(BOOL)shareAppExtentToScene:(NSString*)extInfo
                         url:(NSString*)url
                 photoBase64:(NSString*)base64
                   withTitle:(NSString*)title
                 description:(NSString *)desc
                        data:(NSData*) data
                       sence:(int)sence
{
    SendMessageToWXReq * req = [SendMessageToWXReq new];
    WXMediaMessage * message = [WXMediaMessage message];
    
    UIImage * BaseImage = [[UIImage alloc] initWithData:[[NSData    alloc] initWithBase64EncodedString:base64 options:0]];
    [message setThumbImage:BaseImage];
    message.title = title;
    message.description = desc;
    
    WXAppExtendObject *appextend = [WXAppExtendObject object];
    appextend.extInfo = extInfo;
    appextend.url = url;
    
    NSData* fileData = nil;
    if(data == nil)
    {
        Byte* pBuffer = (Byte *)malloc(10);
        memset(pBuffer, 0, 10);
        fileData = [NSData dataWithBytes:pBuffer length:10];
        free(pBuffer);
    }else{
        fileData = data;
    }
    appextend.fileData =fileData;
    
    
    message.mediaObject = appextend;
    
    req.bText = NO;
    req.message = message;
    req.scene = sence;
    req.text = @"Send from Webuzz";
    
    BOOL success = [WXApi sendReq:req];
    
    return success;
}


- (UIImage *)addImage:(UIImage *)useImage addImage1:(UIImage *)addImage1 image1Width:(float)w image1Height:(float)h
{
    UIGraphicsBeginImageContext(useImage.size);
    [useImage drawInRect:CGRectMake(0, 0, useImage.size.width, useImage.size.height)];
    [addImage1 drawInRect:CGRectMake(useImage.size.width-(w+2.0f), useImage.size.height-(h+2.0f), w, h)];
    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return resultingImage;
}

- (UIImage *)getThumbData:(UIImage *)useImage
{
    UIGraphicsBeginImageContext(useImage.size);
    [useImage drawInRect:CGRectMake(0, 0, 40, 40)];
    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return resultingImage;
}


//-(UIImage *)addText:(UIImage *)img text:(NSString *)text1
//{
//    //get image width and height
//    int w = img.size.width;
//    int h = img.size.height;
//    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
//    //create a graphic context with CGBitmapContextCreate
//    CGContextRef context = CGBitmapContextCreate(NULL, w, h, 8, 4 * w, colorSpace, kCGImageAlphaPremultipliedFirst);
//    CGContextDrawImage(context, CGRectMake(0, 0, w, h), img.CGImage);
//    CGContextSetRGBFillColor(context, 0.0, 1.0, 1.0, 1);
//    char* text = (char *)[text1 cStringUsingEncoding:NSASCIIStringEncoding];
//    CGContextSelectFont(context, "Georgia", 20, kCGEncodingMacRoman);
//    CGContextSetTextDrawingMode(context, kCGTextFill);
//    CGContextSetRGBFillColor(context, 255, 215, 0, 1);
//    CGContextShowTextAtPoint(context, w-strlen(text)*10, h-30, text, strlen(text));
//    //Create image ref from the context
//    CGImageRef imageMasked = CGBitmapContextCreateImage(context);
//    CGContextRelease(context);
//    CGColorSpaceRelease(colorSpace);
//    return [UIImage imageWithCGImage:imageMasked];
//}
RCT_EXPORT_METHOD(shareToSession:(NSDictionary *)data
                  :(RCTResponseSenderBlock)callback)
{
    [self shareToWeixinWithData:data scene:WXSceneSession callback:callback];
}

RCT_EXPORT_METHOD(pay:(NSDictionary *)data
                     :(RCTResponseSenderBlock)callback)
{
    PayReq* req             = [PayReq new];
    req.partnerId           = data[@"partnerId"];
    req.prepayId            = data[@"prepayId"];
    req.nonceStr            = data[@"nonceStr"];
    req.timeStamp           = [data[@"timeStamp"] unsignedIntValue];
    req.package             = data[@"package"];
    req.sign                = data[@"sign"];
    BOOL success = [WXApi sendReq:req];
    callback(@[success ? [NSNull null] : INVOKE_FAILED]);
}

- (void)handleOpenURL:(NSNotification *)note
{
    NSDictionary *userInfo = note.userInfo;
    NSString *url = userInfo[@"url"];
    [WXApi handleOpenURL:[NSURL URLWithString:url] delegate:self];
}

- (void)shareToWeixinWithData:(NSDictionary *)aData image:(UIImage *)aImage scene:(int)aScene callBack:(RCTResponseSenderBlock)callback
{
    SendMessageToWXReq* req = [SendMessageToWXReq new];
    req.scene = aScene;
    
    NSString *type = aData[RCTWXShareType];
    
    if ([type isEqualToString:RCTWXShareTypeText]) {
        req.bText = YES;
        
        NSString *text = aData[RCTWXShareText];
        if (text && [text isKindOfClass:[NSString class]]) {
            req.text = text;
        }
    }
    else {
        req.bText = NO;
        
        WXMediaMessage* mediaMessage = [WXMediaMessage new];
        
        mediaMessage.title = aData[RCTWXShareTitle];
        mediaMessage.description = aData[RCTWXShareDescription];
        mediaMessage.mediaTagName = aData[@"mediaTagName"];
        mediaMessage.messageAction = aData[@"messageAction"];
        mediaMessage.messageExt = aData[@"messageExt"];
        
        if ([type isEqualToString:RCTWXShareTypeImage]) {
            WXImageObject *imageObject = [WXImageObject new];
            imageObject.imageData = UIImageJPEGRepresentation(aImage, 0.7);
            mediaMessage.mediaObject = imageObject;
        }
        else {
            [mediaMessage setThumbImage:aImage];
            
            if (type.length <= 0 || [type isEqualToString:RCTWXShareTypeNews]) {
                WXWebpageObject* webpageObject = [WXWebpageObject new];
                webpageObject.webpageUrl = aData[RCTWXShareWebpageUrl];
                mediaMessage.mediaObject = webpageObject;
                
                if (webpageObject.webpageUrl.length<=0) {
                    callback(@[@"webpageUrl不能为空"]);
                    return;
                }
            }
            else if ([type isEqualToString:RCTWXShareTypeAudio]) {
                WXMusicObject *musicObject = [WXMusicObject new];
                musicObject.musicUrl = aData[@"musicUrl"];
                musicObject.musicLowBandUrl = aData[@"musicLowBandUrl"];
                musicObject.musicDataUrl = aData[@"musicDataUrl"];
                musicObject.musicLowBandDataUrl = aData[@"musicLowBandDataUrl"];
                mediaMessage.mediaObject = musicObject;
            }
            else if ([type isEqualToString:RCTWXShareTypeVideo]) {
                WXVideoObject *videoObject = [WXVideoObject new];
                videoObject.videoUrl = aData[@"videoUrl"];
                videoObject.videoLowBandUrl = aData[@"videoLowBandUrl"];
                mediaMessage.mediaObject = videoObject;
            }
        }
        
        req.message = mediaMessage;
    }
    
    BOOL success = [WXApi sendReq:req];
    if (success == NO)
    {
        callback(@[INVOKE_FAILED]);
    }
}


- (void)shareToWeixinWithData:(NSDictionary *)aData scene:(int)aScene callback:(RCTResponseSenderBlock)aCallBack
{
    NSString *imageUrl = aData[RCTWXShareImageUrl];
    if (imageUrl.length && _bridge.imageLoader) {
        CGSize size = CGSizeZero;
        if (![aData[RCTWXShareType] isEqualToString:RCTWXShareTypeImage]) {
            CGFloat thumbImageSize = 80;
            if (aData[RCTWXShareThumbImageSize]) {
                thumbImageSize = [aData[RCTWXShareThumbImageSize] floatValue];
            }
            size = CGSizeMake(thumbImageSize,thumbImageSize);
        }
        [_bridge.imageLoader loadImageWithTag:imageUrl size:size scale:1 resizeMode:UIViewContentModeScaleToFill progressBlock:nil completionBlock:^(NSError *error, UIImage *image) {
            [self shareToWeixinWithData:aData image:image scene:aScene callBack:aCallBack];
        }];
    }
    else {
        [self shareToWeixinWithData:aData image:nil scene:aScene callBack:aCallBack];
    }
}

- (void)_autoRegisterAPI
{
    if (gAppID.length > 0 && gIsAppRegistered) {
        return;
    }
    
    NSArray *list = [[[NSBundle mainBundle] infoDictionary] valueForKey:@"CFBundleURLTypes"];
    for (NSDictionary *item in list) {
        NSString *name = item[@"CFBundleURLName"];
        if ([name isEqualToString:@"weixin"]) {
            NSArray *schemes = item[@"CFBundleURLSchemes"];
            if (schemes.count > 0)
            {
                gAppID = schemes[0];
                break;
            }
        }
    }
    gIsAppRegistered = [WXApi registerApp:gAppID];
}


- (NSString *)_getErrorMsg:(int)code {
    switch (code) {
        case WXSuccess:
            return @"成功";
        case WXErrCodeCommon:
            return @"普通错误类型";
        case WXErrCodeUserCancel:
            return @"用户点击取消并返回";
        case WXErrCodeSentFail:
            return @"发送失败";
        case WXErrCodeAuthDeny:
            return @"授权失败";
        case WXErrCodeUnsupport:
            return @"微信不支持";
        default:
            return @"失败";
    }
}

#pragma mark - wx callback
- (void)onReq:(BaseReq*)req
{
    if([req isKindOfClass:[ShowMessageFromWXReq class]])
    {
        ShowMessageFromWXReq* temp = (ShowMessageFromWXReq*)req;
        WXMediaMessage *msg = temp.message;        //显示微信传过来的内容
        WXAppExtendObject *obj = msg.mediaObject;
        /* //Test code here
        NSString *strTitle = [NSString stringWithFormat:@"微信请求App显示内容"];
        NSString *strMsg = [NSString stringWithFormat:@"openID: %@, 标题：%@ \n内容：%@ \n附带信息：%@ \n缩略图:%u bytes\n附加消息:%@\n", temp.openID, msg.title, msg.description, obj.extInfo, (unsigned)msg.thumbData.length, msg.messageExt];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
         */
        [self.bridge.eventDispatcher sendAppEventWithName:@"WeChat_Req" body:obj.extInfo];
    }
}

- (void)onResp:(BaseResp*)resp
{
    NSMutableDictionary *body = @{@"errCode":@(resp.errCode)}.mutableCopy;
    body[@"errCode"] = @(resp.errCode);
    
    if (resp.errStr == nil || resp.errStr.length<=0) {
        body[@"errMsg"] = [self _getErrorMsg:resp.errCode];
    }
    else{
        body[@"errMsg"] = resp.errStr;
    }
    
    if([resp isKindOfClass:[SendMessageToWXResp class]])
    {
        SendMessageToWXResp *r = (SendMessageToWXResp *)resp;
        body[@"lang"] = r.lang;
        body[@"country"] =r.country;
        body[@"type"] = @"SendMessageToWX.Resp";
    }
    else if ([resp isKindOfClass:[SendAuthResp class]]) {
        SendAuthResp *r = (SendAuthResp *)resp;
        body[@"state"] = r.state;
        body[@"lang"] = r.lang;
        body[@"country"] =r.country;
        body[@"type"] = @"SendAuth.Resp";
        body[@"appid"] = gAppID;
        body[@"code"]= r.code;
    }
    else if([resp isKindOfClass:[PayResp class]]) {
        PayResp *r = (PayResp *)resp;
        body[@"appid"] = gAppID;
        body[@"returnKey"] = r.returnKey;
        body[@"type"]= @"Pay.Resp";
    }
    
    [self.bridge.eventDispatcher sendAppEventWithName:@"WeChat_Resp" body:body];
}

@end
