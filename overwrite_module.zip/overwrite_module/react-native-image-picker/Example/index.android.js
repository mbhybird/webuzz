import React from 'react-native';
import App from './App';

class Example extends React.Component {
  render() {
    return (
      <App />
    );
  }
}

React.AppRegistry.registerComponent('Example', () => Example);
